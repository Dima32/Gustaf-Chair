Product: Gustaf Chair, December 2014

Designer: Gustaf Sjostrand

Support:  http://forums.obrary.com/category/designs/gustaf-chair

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design